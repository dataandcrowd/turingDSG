library(tidyverse)
library(tidyquant)
library(sf)
library(leaflet)
library(plotly)
library(feather)

Sys.setlocale("LC_ALL","English")


# Import Lower Super Output Area of Bristol
# Import air quality data
lsoa <- read_sf("bristol_lsoa/lsoa110.shp")
#aq <- read_delim("air-quality-data-continuous.csv", ";", escape_double = FALSE, trim_ws = TRUE) %>% arrange(datetime)
aq <- read_feather("air_and_weather.feather") %>% arrange(datetime)


# Convert the stringed coordinates to separate columns
#aq <- aq %>% 
#      separate(geo_point_2d, sep = ", ", into = c("lat", "lon")) %>% 
#      mutate(lon = as.numeric(lon),
#             lat  = as.numeric(lat))

# Check the location_names
aq %>% select(location_name, lon, lat) %>% unique() -> location_names_alltime

# Overall location_names 16
location_names_alltime %>% 
  leaflet() %>% 
  addTiles() %>%
  addMarkers(~lon, ~lat, label = ~as.character(location_name))  

# Start and End Date
aq %>%
  mutate(Date = date(datetime)) %>% 
  select(location_name, Date) %>% unique() %>% 
  group_by(location_name) %>% 
  summarise(Date_End = min(Date), 
            Date_Start = max(Date)) -> start_end



# Sort stations which are currently measured
aq %>% 
  select(location_name, site, lon, lat) %>% 
  filter(site %in% c(452,203,501,463,270,215,500)) %>% 
  unique() -> location_names_realtime


# Overall location_names
location_names_realtime %>% 
  leaflet() %>% 
  addTiles() %>%
  addMarkers(~lon, ~lat, label = ~as.character(location_name))  


  
# Temporal plot
aq %>%
  select(location_name, site, datetime, NO2) %>% 
  mutate(location_name = case_when(location_name == "Cheltenham Road \\ Station Road" ~ "Cheltenham Rd",
                                   location_name == "Newfoundland Road Police Station" ~ "Newfoundland Rd",
                                   location_name == "Wells Road A37 Airport Road Junction" ~ "Wells Rd", 
                                   TRUE ~ as.character(location_name))) -> no2_temp
no2_temp %>% 
  ggplot(aes(datetime, NO2, site)) +
  geom_line() +
  xlab("") +
  ylim(0,400) +
  facet_wrap(~location_name + site) +
  theme_tq() +
  theme(legend.position="none",
        axis.text.x = element_text(size = 13, angle = 90),
        axis.text.y = element_text(size = 13),
        axis.title.y = element_text(size = 15),
        strip.text = element_text(size=15)) -> no2_temp_plot

ggsave("no2_temporal.png", no2_temp_plot, width = 10, height = 7, dpi = 600)

## Counts over 200ug/m3
no2_temp %>% 
  group_by(location_name) %>% 
  summarise(mean_no2 = round(mean(NO2, na.rm = T),1),
            exceedance = length(NO2 >= 200)) %>% 
  arrange(mean_no2) -> ttable

#write.csv(ttable, "table.csv")

###################
aq$days <- lubridate::wday(aq$datetime, label = T)
aq$hour <- lubridate::hour(aq$datetime)
aq$Date <- lubridate::date(aq$datetime)
aq$weekdays  <- ifelse(aq$days == "Sun" | aq$days == "Sat", "weekend", "weekdays")

no2 <- aq %>% 
  select(Date, NO2, location_name, weekdays, hour) %>% 
  reshape2::melt(id = c("Date", "location_name", "weekdays", "hour"), 
                 variable.name = "Type", value.name = "Value")


no2.tib <- as_tibble(no2) %>%
  mutate(location_name = case_when(location_name == "Cheltenham Road \\ Station Road" ~ "Cheltenham Rd",
                                   location_name == "Newfoundland Road Police Station" ~ "Newfoundland Rd",
                                   location_name == "Wells Road A37 Airport Road Junction" ~ "Wells Rd", 
                                   TRUE ~ as.character(location_name))) %>% 
  group_by(location_name, hour, weekdays)


no2.day <- no2.tib %>%
  tq_transmute(
    select     = Value,
    mutate_fun = apply.daily, 
    FUN        = mean,
    na.rm      = TRUE,
    col_rename = "mean_no2"
  )

no2.day$mean_no2[is.nan(no2.day$mean_no2) == T] <- NA
no2.day <- na.omit(no2.day)


no2.day %>% 
  ggplot(aes(x = Date, y = mean_no2, color = location_name)) +
  geom_line() +
  labs(x = "", y = "Concentration") +
  facet_wrap(~ location_name, scale = "free_y") +
  theme_bw() +
  theme(legend.position="none",
        axis.text.x = element_text(size = 20),
        axis.text.y = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        strip.text = element_text(size=20)) -> no2_temp_2018

ggsave("no2_temporal_daily.png", no2_temp_2018, width = 10, height = 7, dpi = 600)


no2.day %>%
  filter(location_name == "AURN St Pauls") %>% 
  ggplot(aes(x = Date, y = mean_nox, color = location_name)) +
  geom_line() +
  labs(x = "", y = "Concentration") +
  theme_bw() +
  theme(legend.position="none",
        axis.text.x = element_text(size = 20),
        axis.text.y = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        strip.text = element_text(size=20)) -> nox_stpaul2018_plot


#ggplotly(nox_stpaul2018_plot)



no2.month <- no2.tib %>%
  tq_transmute(
    select     = Value,
    mutate_fun = apply.monthly, 
    FUN        = mean,
    na.rm      = TRUE,
    col_rename = "mean_no2"
  )

no2.month$mean_no2[is.nan(no2.month$mean_no2) == T] <- NA
no2.month <- na.omit(no2.month)



no2.month %>%
  ggplot(aes(x = hour, y = mean_no2, group = hour, fill = location_name)) +
  geom_boxplot() +
  labs(x = "", y = "Concentration") +
  facet_wrap(~ location_name, scale = "free_y") +
  theme_tq() +
  theme(legend.position="none",
        axis.text.x = element_text(size = 20),
        axis.text.y = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        strip.text = element_text(size=20)) -> nox_box_month

ggsave("no2_box_month_hour.png", nox_box_month, width = 15, height = 10, dpi = 600)

##############
#--Nox 2018--#
##############

aq %>% select(datetime, location_name, site, NO2) %>% 
  filter(datetime >= "2018-01-01", site != 566) -> no2.2018

no2.2018 %>% 
  ggplot(aes(datetime, NO2, site, group = location_name, colour = location_name)) +
  geom_line() +
  geom_hline(aes(yintercept= 200), lwd = 1, color="black", linetype="dashed", alpha = .3) +
  facet_wrap(~location_name + site, scales = "free") +
  theme_tq() +
  theme(legend.position="none",
        axis.text.x = element_text(size = 15),
        axis.text.y = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        strip.text = element_text(size=15)) -> nox.2018.plot
  
ggsave("nox_line_2018.png", nox.2018.plot, width = 10, height = 6, dpi = 600)

############################
#-- Weekdays vs Weekends --#
############################

no2.2018 %>%
  mutate(location_name = case_when(location_name == "Cheltenham Road \\ Station Road" ~ "Cheltenham Rd",
                                   location_name == "Newfoundland Road Police Station" ~ "Newfoundland Rd",
                                   location_name == "Wells Road A37 Airport Road Junction" ~ "Wells Rd", 
                                   TRUE ~ as.character(location_name)),
         weekdays = wday(no2.2018$datetime, label = TRUE)
         ) -> no2.2018.week

no2.2018.week %>% 
  ggplot(aes(weekdays, NO2, group = weekdays, fill = weekdays)) +
  geom_boxplot() +
  ylim(0,150) + 
  xlab("") +
  geom_hline(aes(yintercept= 40), lwd = 1, color="black", linetype="dashed", alpha = .3) +
  facet_wrap(~location_name + site, scales = "free") +
  theme_tq() +
  theme(legend.position="none",
        axis.text.x = element_text(size = 15),
        axis.text.y = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        strip.text = element_text(size=15)) -> no2.2018.plot.wd

ggsave("no2_box_2018.png", no2.2018.plot.wd, width = 12, height = 8, dpi = 600)


############
#--Daily --#
############

no2.2018 %>% 
  mutate(location_name = case_when(location_name == "Cheltenham Road \\ Station Road" ~ "Cheltenham Rd",
                                   location_name == "Newfoundland Road Police Station" ~ "Newfoundland Rd",
                                   location_name == "Wells Road A37 Airport Road Junction" ~ "Wells Rd", 
                                   TRUE ~ as.character(location_name)),
         weekdays = wday(no2.2018$datetime, label = TRUE),
  Date = date(datetime)) %>%
  select(-datetime) %>% 
  group_by(weekdays, site, location_name) %>% 
  tq_transmute(
    select     = NO2,
    mutate_fun = apply.daily, 
    FUN        = mean,
    na.rm      = TRUE,
    col_rename = "daily_no2"
  ) -> no2.2018.daily

no2.2018.daily <- no2.2018.daily[!is.nan(no2.2018.daily$daily_no2),] %>% arrange(Date)


#############
#--holiday--#
#############

holiday <- read.csv("holiday.csv") %>% 
            mutate(date = date(date))

no2.2018.daily.holiday <- no2.2018.daily %>% 
  filter(Date >= "2018-08-01") %>% 
  left_join(holiday, by = c("Date" = "date")) %>% 
  na.omit()


no2.2018.daily.holiday %>% 
  ggplot(aes(holiday_school, daily_no2, group = holiday_school, fill = holiday_school)) +
  geom_boxplot(width=0.5, outlier.shape=NA) +
  xlab("") +
  ylim(0,80) +
  geom_hline(aes(yintercept= 40), lwd = 1, color="black", linetype="dashed", alpha = .3) +
  facet_wrap(~ location_name + site, scales = "free") +
  theme_tq() +
  theme(legend.position="none",
        axis.text.x = element_text(size = 15),
        axis.text.y = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        strip.text = element_text(size=15)) -> no2.2018.holiday.gg

ggsave("no2_box_holiday.png", no2.2018.holiday.gg, width = 10, height = 8, dpi = 600)


no2.2018.daily.holiday %>% 
  ggplot(aes(holiday_bank, daily_no2, group = holiday_bank, fill = holiday_bank)) +
  geom_boxplot(width=0.5, outlier.shape=NA) +
  geom_hline(aes(yintercept= 40), lwd = 1, color="black", linetype="dashed", alpha = .3) +
  facet_wrap(~ location_name + site, scales = "free") +
  xlab("") +
  ylim(0,80) +
  theme_tq() +
  theme(legend.position="none",
        axis.text.x = element_text(size = 15),
        axis.text.y = element_text(size = 20),
        axis.title.y = element_text(size = 20),
        strip.text = element_text(size=15)) -> no2.2018.bank.gg

ggsave("no2_box_bank.png", no2.2018.bank.gg, width = 10, height = 8, dpi = 600)


no2.2018.daily.holiday %>% as.data.frame() %>% 
  select(Date, weekend, daily_no2) %>%
  group_by(Date, weekend) %>% 
  summarise(daily = mean(daily_no2)) %>% 
  reshape2::dcast(Date ~ weekend, value.var = "daily") -> test


t.test(test$`FALSE`, test$`TRUE`)


#############
