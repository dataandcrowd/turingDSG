library(tidyverse)
library(tidyquant)
library(sf)
library(feather)
library(openair)

Sys.setlocale("LC_ALL","English")

aq <- read_feather("air_and_weather.feather") %>% 
  arrange(datetime) %>% 
  select(site, location_name, datetime, NOx, NO2, NO, PM10, 
         temperature_mean, wind_direction_mean, wind_speed_mean, humidity_mean) %>% 
  mutate(Date = date(datetime),
         location_name = case_when(location_name == "Cheltenham Road \\ Station Road" ~ "Cheltenham Rd",
                                   location_name == "Newfoundland Road Police Station" ~ "Newfoundland Rd",
                                   location_name == "Wells Road A37 Airport Road Junction" ~ "Wells Rd", 
                                   TRUE ~ as.character(location_name)))

# Filter Parson Street Road
parson <- aq %>% filter(location_name == "Parson Street School", Date >= "2018-01-01")

# Openair
parson_air <- rename(parson, date = datetime, ws = wind_speed_mean, wd = wind_direction_mean)
summaryPlot(parson_air, percentile = 0.95, fontsize = 20)

# 
calendarPlot(parson_air, pollutant = "NO2", year = 2018, w.shift = 2, fontsize = 20)
calendarPlot(parson_air, pollutant = "NO2", year = 2019, w.shift = 2)

# Wind Rose
windRose(parson_air, type = "NO2", layout = c(4, 1))

# Pollution Rose
pollutionRose(parson_air, pollutant = "NO2",breaks = c(0,30,60,90), fontsize = 30)

# Percentile Rose

percentileRose(parson_air, pollutant = "NO2",
               type = c("season","daylight"),
               percentile = c(25, 50, 75, 90, 95, 99, 99.9),
               key.position = "bottom",
               fontsize = 20,
               longitude = -2.57138, # Parson Street School Longitude
               latitude = 51.44254, # Parson Street School Latitude
               col = "Set3",
               mean.col = "black",
               smooth = T)

#
polarCluster(parson_air, pollutant="NO2")#, n.clusters=2:10, cols= "Set2")
polarFreq(parson_air, pollutant="NO2", statistic = "weighted.mean", type="year", fontsize = 20)


## split data into two periods (see Utlities section for more details)
mydata <- splitByDate(parson_air, dates= "2018-01-01 01:00:00",
                      labels = c("before Jan. 2018", "After Aug. 2018"))

timeVariation(mydata, pollutant = "NO2", statistic = "median", fontsize = 20, col = "jet")
